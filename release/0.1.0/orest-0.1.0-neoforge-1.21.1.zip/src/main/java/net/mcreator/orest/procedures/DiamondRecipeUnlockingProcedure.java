package net.mcreator.orest.procedures;

import net.neoforged.neoforge.event.entity.player.ItemEntityPickupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;

import java.util.Collections;

@EventBusSubscriber
public class DiamondRecipeUnlockingProcedure {
	@SubscribeEvent
	public static void onPickup(ItemEntityPickupEvent.Pre event) {
		execute(event, event.getPlayer(), event.getItemEntity().getItem());
	}

	public static void execute(Entity entity, ItemStack itemstack) {
		execute(null, entity, itemstack);
	}

	private static void execute(@Nullable Event event, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		String recipe_prefix = "";
		String block = "";
		recipe_prefix = "orest:";
		if (itemstack.getItem() == Items.TOTEM_OF_UNDYING || itemstack.getItem() == Items.DIAMOND) {
			block = "toul_2";
		}
		if (itemstack.getItem() == Items.REDSTONE || itemstack.getItem() == Items.DIAMOND) {
			block = "diamond_decompresser";
		}
		if (itemstack.getItem() == Blocks.OAK_PLANKS.asItem() || itemstack.getItem() == Blocks.SPRUCE_PLANKS.asItem() || itemstack.getItem() == Blocks.BIRCH_PLANKS.asItem() || itemstack.getItem() == Blocks.JUNGLE_PLANKS.asItem()
				|| itemstack.getItem() == Blocks.ACACIA_PLANKS.asItem() || itemstack.getItem() == Blocks.DARK_OAK_PLANKS.asItem() || itemstack.getItem() == Blocks.CRIMSON_PLANKS.asItem() || itemstack.getItem() == Blocks.WARPED_PLANKS.asItem()
				|| itemstack.getItem() == Blocks.MANGROVE_PLANKS.asItem() || itemstack.getItem() == Blocks.CHERRY_PLANKS.asItem() || itemstack.getItem() == Items.DIAMOND) {
			block = "diamond_shield";
		}
		if (entity instanceof ServerPlayer _serverPlayer)
			_serverPlayer.awardRecipesByKey(Collections.singletonList(ResourceLocation.parse(((recipe_prefix + "" + block + "_recipe")).toLowerCase(java.util.Locale.ENGLISH))));
	}
}
