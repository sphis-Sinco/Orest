
package net.mcreator.orest.item;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class DiamondShieldItem extends ShieldItem {
	public DiamondShieldItem() {
		super(new Item.Properties().durability(800));
	}

	@Override
	public boolean isValidRepairItem(ItemStack itemstack, ItemStack repairitem) {
		return Ingredient.of(new ItemStack(Items.DIAMOND), new ItemStack(Blocks.DIAMOND_BLOCK)).test(repairitem);
	}
}
