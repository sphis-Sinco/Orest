
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.orest.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.orest.block.WitheredDiamondDecompresserBlock;
import net.mcreator.orest.block.DiamondDecompresserBlock;
import net.mcreator.orest.OrestMod;

public class OrestModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(OrestMod.MODID);
	public static final DeferredBlock<Block> DIAMOND_DECOMPRESSER = REGISTRY.register("diamond_decompresser", DiamondDecompresserBlock::new);
	public static final DeferredBlock<Block> WITHERED_DIAMOND_DECOMPRESSER = REGISTRY.register("withered_diamond_decompresser", WitheredDiamondDecompresserBlock::new);
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
