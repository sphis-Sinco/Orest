
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.orest.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.orest.item.TotemOfUndyingLV2Item;
import net.mcreator.orest.item.DiamondShieldItem;
import net.mcreator.orest.OrestMod;

public class OrestModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(OrestMod.MODID);
	public static final DeferredItem<Item> TOTEM_OF_UNDYING_LV_2 = REGISTRY.register("totem_of_undying_lv_2", TotemOfUndyingLV2Item::new);
	public static final DeferredItem<Item> DIAMOND_DECOMPRESSER = block(OrestModBlocks.DIAMOND_DECOMPRESSER);
	public static final DeferredItem<Item> WITHERED_DIAMOND_DECOMPRESSER = block(OrestModBlocks.WITHERED_DIAMOND_DECOMPRESSER);
	public static final DeferredItem<Item> DIAMOND_SHIELD = REGISTRY.register("diamond_shield", DiamondShieldItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ItemsClientSideHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public static void clientLoad(FMLClientSetupEvent event) {
			event.enqueueWork(() -> {
				ItemProperties.register(DIAMOND_SHIELD.get(), ResourceLocation.parse("minecraft:blocking"), ItemProperties.getProperty(new ItemStack(Items.SHIELD), ResourceLocation.parse("minecraft:blocking")));
			});
		}
	}
}
