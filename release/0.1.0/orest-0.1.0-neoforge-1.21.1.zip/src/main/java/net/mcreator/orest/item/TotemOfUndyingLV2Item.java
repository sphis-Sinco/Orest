
package net.mcreator.orest.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class TotemOfUndyingLV2Item extends Item {
	public TotemOfUndyingLV2Item() {
		super(new Item.Properties().stacksTo(4).rarity(Rarity.UNCOMMON));
	}
}
