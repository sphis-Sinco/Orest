
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.orest.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.core.registries.Registries;

import net.mcreator.orest.world.inventory.DiamondDecompresserGUIMenu;
import net.mcreator.orest.OrestMod;

public class OrestModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, OrestMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<DiamondDecompresserGUIMenu>> DIAMOND_DECOMPRESSER_GUI = REGISTRY.register("diamond_decompresser_gui", () -> IMenuTypeExtension.create(DiamondDecompresserGUIMenu::new));
}
